# Kartly – ThemeForest আপলোড গাইড

## এই জিপের ভেতরে কী আছে

| ফোল্ডার / ফাইল | কাজ |
|---|---|
| `1-Main-File/Kartly-HTML-Template.zip` | **মেইন ফাইল**, ThemeForest-এ "Main Files" হিসেবে আপলোড করবেন |
| `2-Preview-Images/thumbnail-80x80.png` | থাম্বনেইল (৮০×৮০) |
| `2-Preview-Images/theme-preview-590x300.png` | ইনলাইন প্রিভিউ (৫৯০×৩০০) |
| `2-Preview-Images/Screenshots/` | ১২টি স্ক্রিনশট (JPG), "Screenshots" হিসেবে আপলোড করবেন |

## টেমপ্লেটে কী আছে

- ৫টি হোম পেজ: Fashion, Electronics, Grocery, Furniture, Beauty
- ২৫টি ইনার পেজ: Shop Grid/List/Full Width, Product Details ×২, Cart, Checkout, Order Complete, Wishlist, Compare, Login, Register, Forgot Password, My Account, Order Tracking, Blog ×৩, About, Contact, FAQ, Terms, Privacy, 404, Coming Soon
- Bootstrap 5.3, jQuery, Swiper, Font Awesome (সব লাইব্রেরি `assets/` ফোল্ডারে লোকাল)
- ডার্ক মোড, মেগা মেনু, কুইক ভিউ, মিনি কার্ট, প্রোডাক্ট গ্যালারি জুম, কাউন্টডাউন, মোবাইল বটম বার
- `documentation/index.html`, `credits.txt`, `changelog.txt`

## ThemeForest-এ আপলোডের ধাপ

1. ThemeForest Author Dashboard এ গিয়ে **Upload Item** ক্লিক করুন।
2. Category: **Site Templates → Retail → Shopping** (অথবা Retail/Fashion, নিশ অনুযায়ী)।
3. Main File(s): `Kartly-HTML-Template.zip` আপলোড করুন।
4. Thumbnail: `thumbnail-80x80.png`, Theme Preview: `theme-preview-590x300.png`।
5. Screenshots: `Screenshots` ফোল্ডারের ছবিগুলো আপলোড করুন।
6. Live Preview URL: ফোল্ডারটি Netlify বা নিজের হোস্টিংয়ে আপলোড করে URL দিন (`index.html` সহ)।
7. Name: `Kartly – Multipurpose eCommerce HTML5 Template`
8. Tags উদাহরণ: `ecommerce, shop, html5, bootstrap 5, responsive, fashion, electronics, grocery, dark mode, multipurpose`
9. Attributes: Software Version = HTML5; Files Included = HTML, CSS, JS; Columns = 4+; Layout = Responsive; Compatible Browsers = Chrome, Firefox, Safari, Edge।
10. Description-এ ফিচার তালিকা, পেজ সংখ্যা এবং ক্রেডিট লিংক দিন।

## জমা দেওয়ার আগে অবশ্যই করণীয়

1. **প্রোডাক্ট ছবি বদলান:** এখন সব ছবি আমার বানানো সাধারণ SVG ইলাস্ট্রেশন। ThemeForest রিভিউয়াররা বাস্তব ছবিতে ভালো ডিজাইন কোয়ালিটি আশা করেন। লাইসেন্সযুক্ত ফটো (যেমন Unsplash/Pexels) ব্যবহার করলে অনুমোদনের সম্ভাবনা বাড়ে, আর ব্যবহার করলে `credits.txt`-এ উৎস যোগ করুন।
2. **নাম যাচাই করুন:** "Kartly" নামে ThemeForest-এ আগে থেকে কোনো আইটেম আছে কি না সার্চ করে দেখুন। থাকলে সব HTML ফাইলে ও লোগোতে নাম বদলাতে হবে।
3. **ভ্যালিডেশন:** https://validator.w3.org দিয়ে কয়েকটি মূল পেজ পরীক্ষা করুন।
4. **Google Fonts:** টেমপ্লেট Plus Jakarta Sans Google Fonts থেকে লোড করে। এটি ThemeForest-এ গ্রহণযোগ্য, তবে ফন্ট লোকাল চাইলে ফাইল ডাউনলোড করে `assets/fonts`-এ রাখুন।
5. **আগের Ohmly থেকে আলাদা:** Kartly একটি মাল্টিপারপাস টেমপ্লেট, তাই আপনার ইলেকট্রনিক্স-নিশ Ohmly-র সাথে সরাসরি মিলবে না।

> গুরুত্বপূর্ণ: ThemeForest-এর অনুমোদন রিভিউয়ারের সিদ্ধান্তের ওপর নির্ভর করে। আমি কোড, লিংক ও রেসপন্সিভনেস পরীক্ষা করেছি, কিন্তু অনুমোদনের নিশ্চয়তা দিতে পারি না।
